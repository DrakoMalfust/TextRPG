
const readline = require('readline');

const menuItems = [
  'NEW GAME',
  'CONTINUE',
  'SETTINGS',
  'CREDITS',
  'EXIT'
];

let selected = 0;

function drawLoading() {
  return new Promise(resolve => {
    console.clear();
    console.log(`
        .-========-.
        \\'-======-'/
        _|  (..)  |_
       ((|   ██   |))
        \\|  ____  |/
         '------'

       LEGEND OF ERETRIUM
    `);

    let p = 0;
    const timer = setInterval(() => {
      process.stdout.write("\\rLoading [" + "█".repeat(p) + "░".repeat(20-p) + "]");
      p++;
      if (p > 20) {
        clearInterval(timer);
        resolve();
      }
    }, 100);
  });
}

function renderMenu() {
  console.clear();

  console.log(`
      .-========-.
      |  (..)    |
      |   ██     |
      '---------'

      LEGEND OF ERETRIUM

`);

  menuItems.forEach((item, i) => {
    console.log(i === selected ? `> ${item}` : `  ${item}`);
  });

  console.log("\\nUse ↑ ↓ and Enter");
}

async function start() {
  await drawLoading();

  readline.emitKeypressEvents(process.stdin);

  if (process.stdin.isTTY) {
    process.stdin.setRawMode(true);
  }

  renderMenu();

  process.stdin.on('keypress', (_, key) => {
    if (key.name === 'up') {
      selected = (selected - 1 + menuItems.length) % menuItems.length;
      renderMenu();
    }

    if (key.name === 'down') {
      selected = (selected + 1) % menuItems.length;
      renderMenu();
    }

    if (key.name === 'return') {
      console.clear();

      switch(menuItems[selected]) {
        case 'NEW GAME':
          console.log('A new adventure begins...');
          break;
        case 'CONTINUE':
          console.log('No save found.');
          break;
        case 'SETTINGS':
          console.log('Settings coming soon.');
          break;
        case 'CREDITS':
          console.log('Legend of Eretrium Demo');
          break;
        case 'EXIT':
          process.exit(0);
      }
    }
  });
}

start();
