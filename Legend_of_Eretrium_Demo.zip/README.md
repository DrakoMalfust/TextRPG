# Legend of Eretrium Demo

Console RPG demo for Node.js

Run:

npm install
npm start
